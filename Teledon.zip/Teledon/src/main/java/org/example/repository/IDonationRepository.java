package org.example.repository;

import org.example.model.Donation;

public interface IDonationRepository extends IRepository<Integer, Donation> {
}
