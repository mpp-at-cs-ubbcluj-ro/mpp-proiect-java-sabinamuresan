package org.example.repository;

import org.example.model.Volunteer;

public class VolunteerDbRepository implements IVolunteerRepository{
    @Override
    public Volunteer findOne(Integer integer) {
        return null;
    }

    @Override
    public Iterable<Volunteer> getAll() {
        return null;
    }

    @Override
    public Volunteer add(Volunteer entity) {
        return null;
    }

    @Override
    public Volunteer delete(Integer integer) {
        return null;
    }

    @Override
    public Volunteer update(Volunteer entity) {
        return null;
    }
}
